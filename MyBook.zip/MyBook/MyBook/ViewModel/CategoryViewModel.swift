//
//  CategoryViewModel.swift
//  MyBook

import Foundation

enum Category: String, CaseIterable {
    
    case all = "All"
    case horror = "Horror"
    case comedy = "Comedy"
    case moral = "Moral"
        
}
//class CategoryViewModel: ObservableObject {
//    
//    private var bookManager: BookManager
//    @Published var category: Category = .all
//    private var sourceBooks: BookManager
//    
//    init() {
//        
//        loadBooks(category: .all)
//    }
//    
//    func loadBooks(category: Category) {
//        if category == .all {
//            bookManager = sourceBooks
//        } else {
//            bookManager = sourceBooks.books?.filter({ book in
//                return book.category.lowercased() == category.rawValue.lowercased()
//            })
//        }
//    }
//}
