//
//  BookViewModel.swift
//  MyBook


import Foundation

class Book: Identifiable, ObservableObject {
    var id: Int
    var category: String
    var title: String
    var headline: String
    var shortStory: String
    var keyValues: [String]
    var imageName: String
    @Published var isLiked: Bool = false
    
    init(id: Int, category: String, title: String, headline: String, shortStory: String, keyValues: [String], imageName: String, isLiked: Bool) {
            self.id = id
            self.category = category
            self.title = title
            self.headline = headline
            self.shortStory = shortStory
            self.keyValues = keyValues
            self.imageName = imageName
            self.isLiked = isLiked
        }
}


class BookManager:  ObservableObject {
    @Published var books: [Book] = []
        @Published var filteredBooks: [Book] = []
    @Published var likedBooks: Set<UUID> = []
    @Published var selectedCategory: Category = .all {
            didSet {
                filterBooks(by: selectedCategory)
            }
        }

        init(toggleLikeAtIndex index: Int? = nil) {
            setupBooks()
            filterBooks(by: selectedCategory)
            print("load")
//            if let index = index {
//                        toggleLike(for: index)
//                    }
        
        }

    func setupBooks() {
        books = [
            Book(id: 1, category: "Horror", title: "Whispers in the Walls", headline: "A chilling tale of a family haunted by ancestral secrets in an ancient mansion.",
                 shortStory: "The Grayson family moves into an old mansion inherited from a long-lost relative, only to find that the walls whisper secrets of the past, revealing a chilling history that refuses to stay buried.",
                 keyValues: ["Courage in the face of fear", "Importance of family", "Understanding the past"],
                 imageName: "horror1",
                 isLiked: false),
            
            Book(id: 2, category: "Horror", title: "The Dollmaker's Curse", headline: "An antique doll purchased at a quaint village shop brings more than just charm to Clara's home.",
                 shortStory: "Clara finds a beautiful, antique doll that, unbeknownst to her, is cursed. Strange occurrences start to unfold in her home, leading her to uncover the doll's sinister history.",
                 keyValues: ["Caution about the unknown", "Curiosity", "Resilience"],
                 imageName: "horror2",
                 isLiked: true),
            
            Book(id: 3, category: "Horror", title: "Echoes of the Asylum", headline: "A journalist's exploration of an abandoned asylum reveals haunted secrets and personal terror.",
                 shortStory: "Seeking a story, a journalist ventures into an abandoned asylum, only to encounter the tormented spirits of its past, which mirror her own hidden traumas.",
                 keyValues: ["Bravery", "Power of the past to affect the present", "Personal discovery"],
                 imageName: "horror3",
                 isLiked: false),
            
            Book(id: 4, category: "Horror", title: "The Fog of Grimsby", headline: "A mysterious fog covers the town of Grimsby each year, with residents disappearing each time it appears.",
                 shortStory: "Every year, a dense fog descends upon the town, and with it comes a creature that claims residents. This year, a group of friends decides to solve the mystery.",
                 keyValues: ["Unity", "Fighting against odds", "Innovation"],
                 imageName: "horror4",
                 isLiked: true),
            
            Book(id: 5, category: "Horror", title: "Whispering Woods", headline: "A camping trip turns into a nightmare as friends stumble upon a woodland haunted by whispering spirits.",
                 shortStory: "Friends camping in secluded woods hear whispers at night. The whispers grow into voices, leading them through twisted tales of the woods’ past inhabitants.",
                 keyValues: ["Respect for nature", "Courage", "Historical legacies"],
                 imageName: "horror5",
                 isLiked: false),
            
            Book(id: 6, category: "Comedy", title: "The Great Pie Catastrophe", headline: "Hilarity ensues in a small town when a pie baking contest goes hilariously awry.",
                 shortStory: "The town of Berryville hosts its annual pie baking contest, but things take a comedic turn when a mix-up in recipes results in some very unusual pies, leading to laughter and unexpected camaraderie among the townsfolk.",
                 keyValues: ["The joy of laughter", "Community bonding", "Embracing imperfections"],
                 imageName: "comedy1",
                 isLiked: false),
            
            Book(id: 7, category: "Comedy", title: "The Misadventures of Captain Klutz", headline: "A superhero with more enthusiasm than skill tries to save the city, with laughably disastrous results.",
                 shortStory: "Captain Klutz attempts to be the hero his city doesn’t really need, often solving minor problems while inadvertently creating bigger ones, much to the amusement of the citizens.",
                 keyValues: ["Humor in failure", "Perseverance", "Self-awareness"],
                 imageName: "comedy2",
                 isLiked: true),
            
            Book(id: 8, category: "Comedy", title: "The Great Granny Escape", headline: "A group of grandmothers plan a daring escape from their retirement home to attend a rock concert.",
                 shortStory: "Tired of their mundane routine, a spirited group of grandmothers plot a comedic escape from their retirement home to relive their youth at a rock concert.",
                 keyValues: ["Youthfulness at any age", "Adventure", "Friendship"],
                 imageName: "comedy3",
                 isLiked: false),
            
            Book(id: 9, category: "Moral", title: "The Lion's Share", headline: "A wise old lion teaches the jungle animals about fairness and sharing.",
                 shortStory: "Leo, the lion, notices the unrest among the jungle animals as they squabble over food. He devises a clever plan to teach them the importance of sharing and fairness, resulting in a more peaceful jungle.",
                 keyValues: ["Fairness", "The importance of sharing", "Community harmony"],
                 imageName: "moral1",
                 isLiked: true),
            
            Book(id: 10, category: "Moral", title: "The Painter Who Couldn't See", headline: "A blind painter teaches a village the true meaning of vision.",
                 shortStory: "A blind painter moves to a small village and, through his art, shows the villagers that vision isn't only what is seen with the eyes, but what is felt with the heart.",
                 keyValues: ["Perception beyond sight", "Inclusivity", "The essence of art"],
                 imageName: "moral2",
                 isLiked: true),
            
            Book(id: 11, category: "Moral", title: "The Mountain's Secret", headline: "A young climber learns about respect and perseverance from the mountain itself.",
                 shortStory: "Eager to prove himself, a young climber attempts to conquer a challenging mountain only to be turned back repeatedly. The mountain, personified, teaches him respect for nature and the value of perseverance.",
                 keyValues: ["Respect for nature", "Perseverance", "Humility"],
                 imageName: "moral3",
                 isLiked: false),
            
            Book(id: 12, category: "Moral", title: "The Wise Owl's Test", headline: "A wise owl puts three young animals to the test to teach them about wisdom and patience.",
                 shortStory: "An owl, known for its wisdom, challenges three young forest animals with tasks that teach them the importance of patience, thoughtfulness, and wisdom in decision-making.",
                 keyValues: ["Wisdom", "Patience", "The value of careful thought"],
                 imageName: "moral4",
                 isLiked: false)
        ]
    }
//    func toggleShowLikedOnly() {
//            showLikedOnly.toggle()
//            applyFilters()
//        }
//
//        private func applyFilters() {
//            if showLikedOnly {
//                filteredBooks = books.filter { $0.isLiked }
//            } else {
//                filteredBooks = books
//            }
//        }
    func filterBooks(by category: Category) {
                   if category == .all {
                       filteredBooks = books
                   } else {
                       filteredBooks = books.filter { $0.category == category.rawValue }
                   }
               }
    
    func toggleLike(for id: Int) {
            if let index = books.firstIndex(where: { $0.id == id }) {
                books[index].isLiked.toggle()  // This toggles the Boolean value of isLiked
            }
        }
//    func toggleLike(for bookId: Int) {
//        guard let index = books.firstIndex(where: { $0.id == bookId }) else {
//                print("Failed to find book with ID \(bookId)")
//                return
//            }
//            
//            // Debugging output to check current state before toggle
//            print("Before toggle: \(books[index].isLiked) for book \(books[index].title)")
//            
//            books[index].isLiked = true // Attempt to toggle the isLiked status
//            
//            // Debugging output to check state after toggle
//            print("After toggle: \(books[index].isLiked) for book \(books[index].title)")
//
//            // Manually trigger an update in the UI
//            //objectWillChange.send()
//        //books = books.map { $0 }
//        
//        print("books:\(books[index])")// Force SwiftUI to notice the change
//        
//    }

}
