//
//  BookCardView.swift
//  MyBook


import SwiftUI

struct BookCardView: View {
    @ObservedObject var bookManager: BookManager
       
    var book: Book
    
    var body: some View {
        
        VStack(alignment: .leading) {
            VStack {
                HStack{
                    Image(book.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(idealWidth: 150,maxHeight: 150)
                        .padding(10)
                        .shadow(color: Color.black.opacity(0.3), radius: 4, x: 0, y:4)
                    
                }
                .frame(maxWidth: 150, maxHeight: 200)
                .background(.ultraThinMaterial)
                .cornerRadius(15)
                
                VStack(alignment: .leading) {
                    HStack{
                        Text(book.title)
                            .font(.subheadline).bold()
                        Button(action: {
                                                    bookManager.toggleLike(for: book.id)
                                                }) {
                                                    Image(systemName: book.isLiked ? "heart.fill" : "heart")
                                                        .foregroundColor(book.isLiked ? .red : .gray)
                                                        .animation(.easeInOut, value: book.isLiked)
                                                }
//                        Button(action: {
//                            print("Before toggle: \(book.isLiked)")
//                            bookManager.toggleLike(for: book.id)
//                            print("After toggle: \(book.isLiked)")
//                        }) {
//                            
//                            Image(systemName: book.isLiked ? "heart.fill" : "heart")
//                                .foregroundColor(book.isLiked ? .red : .gray)
//                        }
                        
                    }
                    Text(book.headline)
                         .font(.subheadline)
                         .foregroundColor(.black.opacity(0.3))
                }
            }
           
        }
        }
    
}
struct BookCardView_Previews: PreviewProvider {
    static var previews: some View {
       
        BookCardView(bookManager: BookManager(),book: Book(id: 1, category: "Horror", title: "Whispers in the Walls", headline: "A chilling tale of a family haunted by ancestral secrets in an ancient mansion.",
                                shortStory: "The Grayson family moves into an old mansion inherited from a long-lost relative, only to find that the walls whisper secrets of the past, revealing a chilling history that refuses to stay buried.",
                                keyValues: ["Courage in the face of fear", "Importance of family", "Understanding the past"],
                                                           imageName: "horror1", isLiked: false))
        .preferredColorScheme(.light)
    }
}
//
//#Preview {
//    BookCardView()
//}
