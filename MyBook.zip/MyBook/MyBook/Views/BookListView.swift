//
//  BookListView.swift
//  MyBook
//
//  Created by Priya Pravalika Bantu on 5/8/24.
//

import SwiftUI
import FirebaseAuth
struct BookListView: View {
    @AppStorage("uid") var userID: String = ""
    @State var selectedCategory: Category
    @ObservedObject var bookManager: BookManager
    @State var selectedBook: Book? = nil
    @State var showFavouriteView: Bool = false 
    @State var search_bar: String = ""
    private let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 2)
    var body: some View {
        NavigationView {
            
            //            CategorySelectionView(category: $selectedCategory)
            //                .onChange(of: selectedCategory) { newValue in
            //                    //BookViewModel.loadProducts(category: newValue)
            //                } SearchView(text: $search_bar)
            ScrollView {
                //                HorizontalScrolling(bookManager: bookManager)
                //                    .padding(.vertical)
                LazyVGrid(columns: columns) {
                    ForEach(bookManager.filteredBooks) { book in
                        VStack {
                            
                            BookCardView(bookManager:BookManager(),book: book)
                                .onTapGesture {
                                    selectedBook = book
                                }
                        }
                        .padding()
                    }
                    .padding(.vertical)
                    .background(.ultraThickMaterial)
                    .fullScreenCover(item: $selectedBook) { book in
                        BookDetailView(book: book)
                            .preferredColorScheme(.light)
                        
                    }
                }
                .background(.ultraThinMaterial)
                .navigationTitle("Books")
                .navigationBarItems(trailing: HStack {
                    // Category Picker
                    
                    Picker("Category", selection: $bookManager.selectedCategory) {
                        ForEach(Category.allCases, id: \.self) { category in
                            Text(category.rawValue).tag(category)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(width: 230, height: 200)
                    Button(action: {
                                        showFavouriteView.toggle()
                                    }) {
                                        Image(systemName: "heart.fill")
                                            .foregroundColor(.red)
                                    }
                                    .sheet(isPresented: $showFavouriteView) {
                                        FavouriteView(bookManager: bookManager)
                                    }
                    // Sign Out Button
                    Button(action: {
                        let firebaseAuth = Auth.auth()
                        do {
                            try firebaseAuth.signOut()
                            withAnimation {
                                userID = ""
                            }
                        } catch let signOutError as NSError {
                            print("Error signing out: %@", signOutError)
                        }
                    }) {
                        Text("SignOut")
                        //Image(systemName: "SignOut")
                            .foregroundColor(.red)
                    }
                })
            }
        }
    }
}
//struct BookListView_Previews: PreviewProvider {
//    static var previews: some View {
//        BookListView(bookManager: BookManager())
//            .preferredColorScheme(.dark)
//    }
//}

//#Preview {
//    BookListView()
//}
