//
//  CategorySelectionView.swift
//  MyBook
//
//  Created by Priya Pravalika Bantu on 5/9/24.
//

import SwiftUI

struct CategorySelectionView: View {
    @Binding var category: Category
    var body: some View {
        HStack {
            ForEach(Category.allCases, id: \.self) { cat in
                    Button {
                        withAnimation {
                            category = cat
                        }
                    } label: {
                        Text(cat.rawValue)
//                            .bold()
//                            .font(.caption)
//                            .padding(10)
//                            .lineLimit(2)
//                            .multilineTextAlignment(.center)
                            .foregroundColor((category == cat) ? .white : .black)
                    }
                    .frame(height: 60.0)
                    .background(category == cat ? .white : .black)
                    .cornerRadius(25.0)
            }
        }
        .background(.gray)
        .frame(height: 50)
        //.cornerRadius(25.0)
    }
}

struct CategorySelectionView_Previews: PreviewProvider {
    static var previews: some View {
        CategorySelectionView(category: .constant(.comedy))
    }
}

//#Preview {
//    CategorySelectionView()
//}
