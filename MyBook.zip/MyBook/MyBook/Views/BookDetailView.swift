//
//  BookDetailView.swift
//  MyBook

import SwiftUI

struct BookDetailView: View {
    
    var book: Book
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationView{
            ScrollView {
                VStack(alignment: .leading) {
                    VStack {
                        Image(book.imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 150)
                            .padding(10)
                            .shadow(color: Color.black.opacity(0.3), radius: 4, x:0, y: 4)
                    }
                    .background(.ultraThinMaterial)
                    .foregroundColor(.purple.opacity(0.5))
                    .cornerRadius(15)
                    .padding()
                    
                    Text(book.headline)
                        .font(.title).bold()
                        .padding(.horizontal)
                    
                    VStack(alignment: .leading) {
                        VStack(alignment: .leading) {
                            Text("Story:")
                                .font(.title3).bold()
                                .padding(.vertical, 5)
                            Text(book.shortStory)
                                .font(.body)
                                .foregroundColor(.black.opacity(0.7))
                        }
                        .frame(maxHeight: .infinity, alignment: .top)
                        .padding()
                        
                        VStack(alignment: .leading) {
                            Text("KeyValues:")
                                .font(.title3).bold()
                                .padding(.horizontal)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                LazyHStack(spacing: -20) {
                                    ForEach(Array(book.keyValues.enumerated()), id: \.element) { index, keyvalue in
                                            Text(keyvalue)
                                                .foregroundColor(.black.opacity(0.7))
                                                .padding(10)
                                                .background(.ultraThickMaterial)
                                                .cornerRadius(6)
                                                .shadow(color: Color.black.opacity(0.5), radius: 4, x:0, y: 4)
                                        }
                                        .padding(.horizontal)
                                    }
                                }
                                .frame(height: 100)
                            }
                        }
                        //.frame(width: .infinity, height: 400, alignment: .bottomLeading)
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.4), radius: 4, x:0, y: 4)
                        
                    }
                }
                .background(.ultraThinMaterial)
                .navigationTitle(book.title)
                .navigationBarItems(trailing: Image(systemName: "xmark.circle.fill").onTapGesture {
                    dismiss()
                })
            }
            
        }
    }
    
    
    
    struct BookDetailView_Previews: PreviewProvider {
        static var previews: some View {
            BookDetailView(book: Book(id: 1, category: "Horror", title: "Whispers in the Walls", headline: "A chilling tale of a family haunted by ancestral secrets in an ancient mansion.",
                                      shortStory: "The Grayson family moves into an old mansion inherited from a long-lost relative, only to find that the walls whisper secrets of the past, revealing a chilling history that refuses to stay buried.",
                                      keyValues: ["Courage in the face of fear", "Importance of family", "Understanding the past"],
                                      imageName: "horror1", isLiked: false))
            .preferredColorScheme(.light)
        }
    }
    
    //
    //#Preview {
    //    BookDetailView()
    //}

