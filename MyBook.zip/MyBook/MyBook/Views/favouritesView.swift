//
//  favouritesView.swift
//  MyBook
//
//  Created by Priya Pravalika Bantu on 5/10/24.
//

import SwiftUI
//import FirebaseAuth
struct FavouriteView: View {
    @ObservedObject var bookManager: BookManager
    @State var selectedBook: Book? = nil
    private let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 2)

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns) 
            {
                ForEach(bookManager.filteredBooks.filter { $0.isLiked }) { book in
                    VStack {
                        BookCardView(bookManager: bookManager, book: book)
                            .onTapGesture {
                                selectedBook = book
                            }
                    }
                    .padding()
                }
                .padding(.vertical)
                .background(.ultraThinMaterial)
                .fullScreenCover(item: $selectedBook) { book in
                    BookDetailView(book: book)
                        .preferredColorScheme(.light)
                    
                }
            }
            .background(.ultraThinMaterial)
            .navigationTitle("Books")
        }
        .navigationTitle("Favourite Books")
    }
}

//import SwiftUI
//import FirebaseAuth
//
//struct favouritesView: View {
//    @AppStorage("uid") var userID: String = ""
//    @State var selectedCategory: Category
//    @ObservedObject var bookManager: BookManager
//    @State var selectedBook: Book? = nil
//    @State var search_bar: String = ""
//    private let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 2)
//
//    var body: some View {
//        NavigationView {
//            ScrollView {
//                LazyVGrid(columns: columns) {
//                    // Filter books to only include those where `isLiked` is true
//                    ForEach(bookManager.filteredBooks.filter { $0.isLiked }) { book in
//                        VStack {
//                            BookCardView(bookManager: bookManager, book: book)
//                                .onTapGesture {
//                                    selectedBook = book
//                                }
//                        }
//                        .padding()
//                    }
//                    .background(.ultraThickMaterial)
//                    .fullScreenCover(item: $selectedBook) { book in
//                        BookDetailView(book: book)
//                            .preferredColorScheme(.dark)
//                    }
//                }
//                .background(.ultraThinMaterial)
//                .navigationTitle("Books")
//                .navigationBarItems(trailing: HStack {
//                    Picker("Category", selection: $bookManager.selectedCategory) {
//                        ForEach(Category.allCases, id: \.self) { category in
//                            Text(category.rawValue).tag(category)
//                        }
//                    }
//                    .pickerStyle(SegmentedPickerStyle())
//                    .frame(width: 230, height: 200)
//
////                    Button(action: {
////                        // This button could toggle showing only liked books, for example
////                    }) {
////                        Image(systemName: "heart")
////                            .foregroundColor(.red)
////                    }
////                    .frame(width: 25)
//
//                    Button(action: {
//                        let firebaseAuth = Auth.auth()
//                        try? firebaseAuth.signOut()
//                        withAnimation {
//                            userID = ""
//                        }
//                    }) {
//                        Text("SignOut")
//                            .foregroundColor(.red)
//                    }
//                })
//            }
//        }
//    }
//}
//
//
//
////
////#Preview {
////    favouritesView()
////}
