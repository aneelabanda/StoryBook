//
//
//import SwiftUI
//import FirebaseAuth
//struct ContentView: View {
//    @AppStorage("uid") var userID: String = ""
//    
//    var body: some View {
//        
//        if userID == "" {
//           AuthView()
//        } else {
//            VStack {
//                BookListView(selectedCategory: .all, bookManager: BookManager())
//            }
//            .padding()
//            //BookListView(bookManager: <#T##BookManager#>())
////            Text("Logged In! \nYour user id is \(userID)")
////            
////            Button(action: {
////                let firebaseAuth = Auth.auth()
////                do {
////                    try firebaseAuth.signOut()
////                    withAnimation {
////                        userID = ""
////                    }
////                } catch let signOutError as NSError {
////                    print("Error signing out: %@", signOutError)
////                }
////            }) {
////                Text("Sign Out")
////                    
////            }
//        }
//        
//    }
//}
//
//#Preview {
//    ContentView()
//}
//
//
//
//



import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @AppStorage("uid") var userID: String = ""
    @State private var showAuthView = false  // State to control view navigation

    var body: some View {
        NavigationView {
            if userID == "" {
                if showAuthView {
                    AuthView()
                } else {
                    ZStack{
                        LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.3), Color.purple.opacity(0.3)]), startPoint: .top, endPoint: .bottom)
                                        .edgesIgnoringSafeArea(.all)
                        VStack{
                            Image("logo") // Replace "backgroundImageName" with your actual image name in the asset catalog
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .onTapGesture {
                                    showAuthView = true  // Change view on tap
                                }
                            Text("My Story Book")
                                .font(.largeTitle)
                                .multilineTextAlignment(.center)
                                .foregroundColor(.white)
                                .padding()
                                
                        }
                    }
                }
            } else {
                VStack {
                    BookListView(selectedCategory: .all, bookManager: BookManager())
                }
                .padding()
                //BookListView(bookManager: <#T##BookManager#>)
//                Text("Logged In! \nYour user id is \(userID)")
//
//                Button(action: {
//                    let firebaseAuth = Auth.auth()
//                    do {
//                        try firebaseAuth.signOut()
//                        withAnimation {
//                            userID = ""
//                        }
//                    } catch let signOutError as NSError {
//                        print("Error signing out: %@", signOutError)
//                    }
//                }) {
//                    Text("Sign Out")
//
//                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
